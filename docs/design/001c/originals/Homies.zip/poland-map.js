// Poland coverage map — real Natural Earth geometry via d3-geo + topojson.
// Registers itself as <poland-map>. Expects d3 and topojson-client already loading.
(function () {
  const CITIES = [
    { name: 'Warszawa', lon: 21.0122, lat: 52.2297, status: 'live' },
    { name: 'Kraków', lon: 19.9450, lat: 50.0647, status: 'next' },
    { name: 'Wrocław', lon: 17.0385, lat: 51.1079, status: 'next' },
    { name: 'Gdańsk', lon: 18.6466, lat: 54.3520, status: 'next' },
    { name: 'Poznań', lon: 16.9252, lat: 52.4064, status: 'later' },
    { name: 'Łódź', lon: 19.4560, lat: 51.7592, status: 'later' },
    { name: 'Katowice', lon: 19.0238, lat: 50.2649, status: 'later' },
    { name: 'Szczecin', lon: 14.5528, lat: 53.4285, status: 'later' }
  ];
  const URL = 'https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-110m.json';
  let cache = null;

  const waitForLibs = async () => {
    for (let i = 0; i < 200; i++) {
      if (window.d3 && window.topojson) return true;
      await new Promise((r) => setTimeout(r, 50));
    }
    return false;
  };

  class PolandMap extends HTMLElement {
    connectedCallback() {
      this.style.display = 'block';
      this.style.width = '100%';
      this._draw();
      this._ro = new ResizeObserver(() => {
        clearTimeout(this._t);
        this._t = setTimeout(() => this._draw(), 120);
      });
      this._ro.observe(this);
    }
    disconnectedCallback() { if (this._ro) this._ro.disconnect(); }

    async _draw() {
      if (!(await waitForLibs())) return;
      if (!cache) cache = await fetch(URL).then((r) => r.json());
      const feats = window.topojson.feature(cache, cache.objects.countries).features;
      const poland = feats.find((f) => f.properties && f.properties.name === 'Poland');
      if (!poland) return;

      const w = Math.max(320, this.clientWidth || 900);
      const h = Math.round(w * 0.66);
      const proj = window.d3.geoMercator().fitExtent(
        [[w * 0.13, h * 0.1], [w * 0.87, h * 0.9]], poland
      );
      const path = window.d3.geoPath(proj);

      const others = feats
        .filter((f) => f !== poland)
        .map((f) => `<path d="${path(f) || ''}" fill="#e2dfdf" stroke="#f3f2f2" stroke-width="1.5"></path>`)
        .join('');

      const dots = CITIES.map((c) => {
        const p = proj([c.lon, c.lat]);
        if (!p) return '';
        const live = c.status === 'live';
        const r = live ? 7 : 5;
        const fill = live ? '#ec3013' : (c.status === 'next' ? '#f3f2f2' : 'none');
        const stroke = live ? '#f3f2f2' : '#ec3013';
        const anchor = c.lon > 19.5 ? 'start' : 'end';
        const dx = anchor === 'start' ? r + 7 : -(r + 7);
        return `<g>
          <circle cx="${p[0]}" cy="${p[1]}" r="${r}" fill="${fill}" stroke="${stroke}" stroke-width="2"></circle>
          <text x="${p[0] + dx}" y="${p[1] + 4}" text-anchor="${anchor}"
            font-family="Archivo, system-ui, sans-serif" font-size="${live ? 15 : 13}"
            font-weight="${live ? 800 : 600}"
            fill="${live ? '#f3f2f2' : '#c9c4c4'}">${c.name}</text>
        </g>`;
      }).join('');

      this.innerHTML = `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}"
        role="img" aria-label="Homies coverage map of Poland"
        style="display:block;overflow:hidden">
        <rect width="${w}" height="${h}" fill="#f3f2f2"></rect>
        ${others}
        <path d="${path(poland) || ''}" fill="#201e1d" stroke="#201e1d" stroke-width="1"></path>
        ${dots}
      </svg>`;
    }
  }
  if (!customElements.get('poland-map')) customElements.define('poland-map', PolandMap);
})();
