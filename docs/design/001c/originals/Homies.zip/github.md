repo: ihorfroliak/homies
branch: main

## Last sync

date: 2026-10-04T12:31:59Z
commit: 995b05fe72bc15a86141e214bf1c4fc63b8bc570

### Updated in this project

- DESIGN-001C prototype checked against the public classified API at main 995b05fe (pricing fields, utilities_basis, authority scopes).
- Four review corrections applied: price breakdown built only from API fields, guest sign-in sequence, G-14 after an existing viewing, supply-side boundary.

## Screen map

| Screen | Built from |
| --- | --- |
| Homies 001C Dzielnica Product Convergence.dc.html | docs/api/openapi.json (ClassifiedOut, ClassifiedPage, LoginRequest, AuthorityOut, MandateCreate, DecisionIn), FE-002 routes, canonical decisions D-101 / G4 / G9 / F6 / D-103 |
| Homies Seeker v1.dc.html | FE-002 seeker slice (search, list/map, listing detail) |
| Homies DS v1.dc.html | docs/product/DESIGN-SYSTEM-v1.md |
| Homies 001B Kierunki.dc.html / Homies 001B Konwersja FE-003.dc.html | design exploration (not code) |
| Phase 1–8 *.dc.html | earlier repository docs (strategy, project state) |

## Sync history

- 2026-09-17 — eight-phase documentation and index page.
- 2026-08-13 — initial import: landing page from strategy docs.
